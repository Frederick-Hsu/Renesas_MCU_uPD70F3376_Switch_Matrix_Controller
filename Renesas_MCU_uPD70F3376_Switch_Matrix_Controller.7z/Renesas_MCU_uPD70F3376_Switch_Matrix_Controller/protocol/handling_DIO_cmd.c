#include "Parse_UART2_Message.h"

int handling_DIN_cmd(char* sDIN_cmd_Mesg)
{
	return 0;
}


int handling_DOUT_cmd(char* sDOUT_cmd_Mesg)
{
	return 0;
}

