#include "Parse_UART2_Message.h"


int handling_CAN_cmd(char* sCAN_cmd_Mesg)
{
	return 0;
}


int handling_LIN_cmd(char* sLIN_cmd_Mesg)
{
	return 0;
}


int handling_PWM_cmd(char* sPWM_cmd_Mesg)
{
	return 0;
}

