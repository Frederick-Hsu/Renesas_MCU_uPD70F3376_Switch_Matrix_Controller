#include "Parse_UART2_Message.h"

int handling_ADC_cmd(char* sADC_cmd_Mesg)
{
	return 0;
}
	

int handling_DAC_cmd(char* sDAC_cmd_Mesg)
{
	return 0;
}

